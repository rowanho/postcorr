package common

type LSH_fp struct {
	Signature []uint64
}
