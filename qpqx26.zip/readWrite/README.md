# File Structure

## Plaintext dataset format


    |__ Root 

        |__ Sub_folder1

            |__ file1.txt

        |__ Sub_folder2

            |__ file2.txt

...        
